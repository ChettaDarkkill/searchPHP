-- phpMyAdmin SQL Dump
-- version 2.10.3
-- http://www.phpmyadmin.net
-- 
-- โฮสต์: localhost
-- เวลาในการสร้าง: 
-- รุ่นของเซิร์ฟเวอร์: 5.0.51
-- รุ่นของ PHP: 5.2.6

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";

-- 
-- ฐานข้อมูล: `searchonweb`
-- 

-- --------------------------------------------------------

-- 
-- โครงสร้างตาราง `company`
-- 

CREATE TABLE `company` (
  `name` varchar(50) NOT NULL,
  `nation1` varchar(50) default NULL,
  `nation2` varchar(50) default NULL,
  `nation3` varchar(50) default NULL,
  `amount_movie` int(11) NOT NULL,
  `website` varchar(100) default NULL,
  PRIMARY KEY  (`name`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- 
-- dump ตาราง `company`
-- 

INSERT INTO `company` VALUES ('20th century fox', 'USA', 'Canada', 'France', 12, 'http://www.foxmovies.com/');
INSERT INTO `company` VALUES ('China Film Group', 'China', NULL, NULL, 6, 'http://group.chinafilm.com/');
INSERT INTO `company` VALUES ('DreamWorks SKG', 'USA', 'UK', NULL, 7, 'http://www.dreamworksstudios.com/');
INSERT INTO `company` VALUES ('Five StarProduction', 'Thailand', NULL, NULL, 2, 'http://www.fivestarent.com/');
INSERT INTO `company` VALUES ('GTH', 'Thailand', NULL, NULL, 6, 'http://www.gth.co.th/');
INSERT INTO `company` VALUES ('Star Cinema', 'Thailand', NULL, NULL, 1, NULL);
INSERT INTO `company` VALUES ('Universal Picture', 'USA', 'UK', NULL, 8, 'http://www.universalstudios.com/');
INSERT INTO `company` VALUES ('Walt Disney Picture', 'USA', NULL, NULL, 6, 'http://disney.go.com/disneypictures/');

-- --------------------------------------------------------

-- 
-- โครงสร้างตาราง `movie`
-- 

CREATE TABLE `movie` (
  `name` varchar(30) NOT NULL,
  `director` varchar(50) NOT NULL,
  `length` int(11) NOT NULL,
  `type1` varchar(10) default NULL,
  `type2` varchar(10) default NULL,
  `type3` varchar(10) default NULL,
  `company` varchar(30) default NULL,
  `nation` varchar(10) NOT NULL,
  `rate` varchar(50) NOT NULL,
  `year` year(4) NOT NULL,
  `boxoffice` float default NULL,
  PRIMARY KEY  (`name`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- 
-- dump ตาราง `movie`
-- 

INSERT INTO `movie` VALUES ('a good day to die hard', 'John moore', 97, 'Action', 'Crime', 'Thriller', '20thcenturyfox', 'USA', 'PG-13', 2013, 67);
